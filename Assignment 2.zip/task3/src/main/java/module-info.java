module com.example.task3 {
    requires javafx.controls;
    requires javafx.fxml;
    requires okhttp3;
    requires org.json;



    opens com.example.task3 to javafx.fxml;
    exports com.example.task3;
}