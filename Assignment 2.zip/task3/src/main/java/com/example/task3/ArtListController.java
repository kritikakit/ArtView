package com.example.task3;

import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ArtListController {
    // UI elements from the FXML file
    @FXML
    private TextField searchField;   // Text field for filter functionality

    @FXML
    private ListView<String> artListView;  // List view for  displaying art IDs


    private OkHttpClient client = new OkHttpClient();   // HTTP client to make API calls
    private List<String> allArtIDs = new ArrayList<>();  //List to hold all fetched art Ids

    @FXML
    private void initialize() {
        fetchArtIDs();   // Fetch the art IDs from the API
        searchField.textProperty().addListener((observable, oldValue, newValue) -> filterList());  // a listener to the search field to filter the list
    }


    @FXML
    private void fetchArtIDs() {  // method to fetch art ids from the api
        new Thread(() -> {
            Request request = new Request.Builder()  // create request to api
                    .url("https://collectionapi.metmuseum.org/public/collection/v1/search?q=landscape&hasImages=true")
                    .build();

            try (Response response = client.newCall(request).execute()) {
                String body = response.body().string();  // get response as string
                JSONObject jsonObject = new JSONObject(body);                 // Parse the response to JSON object
                JSONArray objectIDsArray = jsonObject.getJSONArray("objectIDs");   // getting array of object ids


                for (int i = 0; i < objectIDsArray.length(); i++) { //loop through array and adding each ID to the list
                    int objectID = objectIDsArray.getInt(i);
                    allArtIDs.add(String.valueOf(objectID));
                }

                javafx.application.Platform.runLater(() -> {  // update the listview
                    artListView.setItems(FXCollections.observableArrayList(allArtIDs));
                });

            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start(); // Start the thread to run the fetch operation asynchronously
    }



    @FXML
    private void filterList() {  //Method to filter the list of art IDs based on user input
        String filter = searchField.getText();  //get the text from search field
        if (filter == null || filter.isEmpty()) {
            artListView.setItems(FXCollections.observableArrayList(allArtIDs));  // If no filter is applied then show the full list
        } else {
            List<String> filteredList = new ArrayList<>();  // If a filter is applied then create a new list with matching IDs
            for (String id : allArtIDs) {
                if (id.contains(filter)) {
                    filteredList.add(id);
                }
            }
            artListView.setItems(FXCollections.observableArrayList(filteredList));   // Update the ListView with the filtered list
        }
    }



    @FXML
    private void showArtDetails() {  // Method to show details of the selected art piece
        String selectedArtID = artListView.getSelectionModel().getSelectedItem();   // Get the selected art ID from the ListView
        if (selectedArtID != null) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("ArtDetailsView.fxml")); // Load the FXML file for the art details view
                Parent artDetailsRoot = loader.load();

                ArtDetailsController artDetailsController = loader.getController();   // Get the controller for the art details view and pass the selected ID
                artDetailsController.loadArtDetails(selectedArtID);

                Stage stage = (Stage) artListView.getScene().getWindow();  // Set the new scene to display the art details
                stage.setScene(new Scene(artDetailsRoot));


            } catch (IOException e) {
                e.printStackTrace();  // Print stack trace if there's an error
            }
        }
    }
}
