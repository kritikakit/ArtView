package com.example.task3;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.InputStream;

public class Main extends Application {


    @Override
    public void start(Stage primaryStage) throws Exception {
        // Load the FXML file to create the GUI
        Parent root = FXMLLoader.load(getClass().getResource("ArtListView.fxml"));


        Scene scene = new Scene(root);     //creating a Scene with the loaded FXML content


        primaryStage.setTitle("Art Gallery"); //title of the main window


        InputStream iconStream = getClass().getResourceAsStream("iconz.jpeg"); // Loading the icon for the application
        if (iconStream != null) {
            Image icon = new Image(iconStream);
            primaryStage.getIcons().add(icon);
        } else {
            System.err.println("Icon file not found.");  //print error if icon is not found
        }


        primaryStage.setScene(scene);  // Set the scene for the stage

        primaryStage.show(); // Show the main window
    }

    public static void main(String[] args) {
        launch(args);  // Launch the JavaFX application
    }
}
