package com.example.task3;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.json.JSONObject;

import java.io.IOException;

public class ArtDetailsController {

    // UI elements from the FXML file
    @FXML
    private ImageView imageView; // ImageView for displaying the art image

    @FXML
    private Label titleLabel;  // Label for displaying the art title


    @FXML
    private Label artistNameLabel;   // Label for displaying the artist's name

    @FXML
    private Label artistBioLabel;  // Label for display the artist's biography

    private OkHttpClient client = new OkHttpClient();      // HTTP client to make API calls


    public void loadArtDetails(String artID) {  // Method to load art details based on the provided art ID
        new Thread(() -> {
            Request request = new Request.Builder()   // Create a request to the API to get details for a specific art ID
                    .url("https://collectionapi.metmuseum.org/public/collection/v1/objects/" + artID)
                    .build();


            try (Response response = client.newCall(request).execute()) {
                String body = response.body().string(); // Get the response as a string
                JSONObject jsonObject = new JSONObject(body); // Parse the response to JSON object


                // Extracting details from the JSON object
                String title = jsonObject.optString("title", "No title available");
                String artistDisplayName = jsonObject.optString("artistDisplayName", "No artist information available");
                String artistDisplayBio = jsonObject.optString("artistDisplayBio", "No artist biography available");
                String imageURL = jsonObject.optString("primaryImage", null);

                javafx.application.Platform.runLater(() -> {  // Update the UI elements on the JavaFX application thread
                    titleLabel.setText("Title: " + title);
                    artistNameLabel.setText("Artist: " + artistDisplayName);
                    artistBioLabel.setText("Artist Bio: " + artistDisplayBio);
                    if (imageURL != null && !imageURL.isEmpty()) {
                        imageView.setImage(new Image(imageURL));   // Set the image if the URL is available
                    } else {
                        imageView.setImage(null);  //set null if image is not available
                    }
                });

            } catch (IOException e) {
                e.printStackTrace(); //if there is error
            }
        }).start(); //start the thread
    }

    @FXML
    private void goBack() {  // Method for going back to the art list view
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("ArtListView.fxml"));  // Load the FXML file for the art list view
            Parent artListRoot = loader.load();


            // Get the current stage and set the new scene to display the art list
            Stage stage = (Stage) titleLabel.getScene().getWindow();
            stage.setScene(new Scene(artListRoot));

        } catch (IOException e) {
            e.printStackTrace(); // if there is error
        }
    }
}
